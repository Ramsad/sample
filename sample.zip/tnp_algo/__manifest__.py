{
    'name': 'TNP algo',
    'version': '1',
    'summary': 'TNP ALgo',
    'description': 'TNP ALgo',
    'category': 'Other',
    'author': 'Ramsad',
    'website': '',
    'license': '',
    'depends': ['base'],
    'data': ['view/data_feed.xml',
             'view/data_feed_cron.xml',
             'view/data_smt.xml',
             'view/data_smt_cron.xml',
             'view/orders.xml',
             'view/orders_cron.xml',
             'view/pair.xml',
             'data/smt_data.xml',
             'data/pair_data.xml',
             'security/ir.model.access.csv'
             ],

    'installable': True,
    'auto_install': False,


}