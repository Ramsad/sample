from odoo import api, fields, models




class Orders(models.Model):
    _name = 'data.order'
    _description = 'Orders '

    pair =  fields.Char(string="Pair", required=False, )
    entry = fields.Float(string="Entry",  required=False, )
    sl = fields.Float(string="Stop Loss",  required=False, )
    tp = fields.Float(string="Take Profit",  required=False, )
    order_id = fields.Char(string="", required=False, )
    order_type  = fields.Selection(string="Order Type", selection=[('buy', 'Buy'), ('sell', 'Sell'), ], required=False, )
    open_time  = fields.Char(string="Open Time", required=False, )
    user_time  = fields.Char(string="User Time", required=False, )
    pnl =  fields.Float(string="PNL",  required=False, )

    def order_creator(self):
        fib_level = self.env['data.smt'].search([('state','=','new'),('smt_valid','=',True),('fib_big','!=',False),('fib_end','!=',False)])

        for rec in fib_level :
            print(rec.fib_level)
            last_candle = self.env['data.feed'].search([('pair','=',rec.pair),('smt_check','=',True)],order='timestamp desc', limit=1)
            if last_candle :
                if rec.smt_direction == "buy" :
                    if last_candle.low < rec.fib_level :
                        rec.fib_break = True
                        rec.state = 'done'
                        print("send order buy")
                        tp = ((rec.fib_level - rec.fib_big) * 3) + rec.fib_level
                        order = self.env['data.order'].create({ 'sl': rec.fib_big ,
                                                                'tp': tp ,
                                                                'pair':rec.pair,
                                                                'order_type':'buy'

                        })

                if rec.smt_direction == "sell" :
                    if last_candle.high > rec.fib_level :
                        rec.fib_break = True
                        rec.state = 'done'
                        print("send order sell")
                        tp = rec.fib_level - ((rec.fib_big - rec.fib_level) * 3)
                        order = self.env['data.order'].create({'sl': rec.fib_big,
                                                               'tp': tp,
                                                               'pair': rec.pair,
                                                               'order_type': 'sell'
                                                               })

