from odoo import api, fields, models


class Pair(models.Model):
    _name = 'data.pair'
    _rec_name = 'name'
    _description = 'Pair'

    name = fields.Char()
