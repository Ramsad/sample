from odoo import api, fields, models


class SMT(models.Model):
    _name = 'data.smt'
    _rec_name = 'pair'
    _description = 'SMT List'

    pair = fields.Char()
    smt_valid = fields.Boolean(string="", )
    sp_point = fields.Many2one(comodel_name="data.feed", string="", required=False, )
    nq_c_point = fields.Many2one(comodel_name="data.feed", string="", required=False, )

    nq_point = fields.Many2one(comodel_name="data.feed", string="", required=False, )
    sp_c_point = fields.Many2one(comodel_name="data.feed", string="", required=False, )

    smt_direction = fields.Selection(string="", selection=[('buy', 'Buy'), ('sell', 'Sell'), ], required=False, )

    previous_fractal_point = fields.Many2one(comodel_name="data.feed", string="", required=False, )
    bos_done = fields.Boolean(string="", )

    fib_big = fields.Float(string="", required=False, )
    fib_end = fields.Float(string="", required=False, )
    fib_level = fields.Float(string="", required=False, compute='compute_fib_level')
    fib_break = fields.Boolean(string="", )

    state = fields.Selection(string="Status", selection=[('new', 'New'), ('done', 'Done'), ], required=False, )

    def compute_fib_level(self):
        for rec in self:
            if rec.fib_big and rec.fib_end:
                if rec.fib_big < rec.fib_end:
                    rec.fib_level = rec.fib_end - ((rec.fib_end - rec.fib_big) * 0.618)
            if rec.fib_big > rec.fib_end:
                rec.fib_level = rec.fib_end + ((rec.fib_big - rec.fib_end) * 0.618)
            if rec.fib_big < rec.fib_end:
                rec.fib_level = rec.fib_end + ((rec.fib_big - rec.fib_end) * 0.618)
            else :
                rec.fib_level = False

    def data_smt_finder(self):
        sp = self.env.ref('tnp_algo.sp').name
        nq = self.env.ref('tnp_algo.nq').name
        # snp_data = self.env['data.feed'].search([('pair','=',sp),('smt_check','=',True)])
        # ndx_data = self.env['data.feed'].search([('pair','=',nq),('smt_check','=',True)])
        #
        # for rec in snp_data :
        #     rec.smt_check = False
        # for rec in ndx_data :
        #     rec.smt_check = False

        snp_data = self.env['data.feed'].search([('pair', '=', sp), ('smt_check', '=', False)])
        ndx_data = self.env['data.feed'].search([('pair', '=', nq), ('smt_check', '=', False)])

        snp_sell = self.env.ref('tnp_algo.smt_snp_sell')
        snp_buy = self.env.ref('tnp_algo.smt_snp_buy')

        nq_sell = self.env.ref('tnp_algo.smt_nq_sell')
        nq_buy = self.env.ref('tnp_algo.smt_nq_buy')

        # SNP
        for record in snp_data:
            record.smt_check = True
            if record.high > snp_sell.sp_point.high:
                snp_sell.sp_point = record
                # nq corresponding point
                nq_record = self.env['data.feed'].search(
                    [('pair', '=', nq), ('timestamp', '=', record.timestamp)])
                if nq_record:
                    snp_sell.nq_c_point = nq_record.id

            if record.low < snp_buy.sp_point.low or snp_buy.sp_point.low == 0:
                snp_buy.sp_point = record

                # nq_corresponding point
                nq_record = self.env['data.feed'].search(
                    [('pair', '=', nq), ('timestamp', '=', record.timestamp)])
                if nq_record:
                    snp_buy.nq_c_point = nq_record.id

            break

        # NQ
        for record in ndx_data:
            record.smt_check = True
            if record.high > nq_sell.nq_point.high:
                nq_sell.nq_point = record

                # snp corresponding point
                snp_record = self.env['data.feed'].search(
                    [('pair', '=', sp), ('timestamp', '=', record.timestamp)])
                if snp_record:
                    nq_sell.sp_c_point = snp_record.id

            if record.low < nq_buy.nq_point.low or nq_buy.nq_point.low == 0:
                nq_buy.nq_point = record

                # snp corresponding point
                snp_record = self.env['data.feed'].search(
                    [('pair', '=', sp), ('timestamp', '=', record.timestamp)])
                if snp_record:
                    nq_buy.sp_c_point = snp_record.id

            break

    def smt_validator(self):
        sp = self.env.ref('tnp_algo.sp').name
        nq = self.env.ref('tnp_algo.nq').name

        snp_sell = self.env.ref('tnp_algo.smt_snp_sell')
        nq_sell = self.env.ref('tnp_algo.smt_nq_sell')

        snp_buy = self.env.ref('tnp_algo.smt_snp_buy')
        nq_buy = self.env.ref('tnp_algo.smt_nq_buy')

        # sell
        # todo setup later

        # Buy
        if snp_buy.sp_point.timestamp < nq_buy.nq_point.timestamp:
            if snp_buy.sp_point.low < nq_buy.sp_c_point.low and snp_buy.nq_c_point > nq_buy.nq_point.low:
                snp_buy.smt_valid = True
                nq_buy.smt_valid = True
            else:
                snp_buy.smt_valid = False
                nq_buy.smt_valid = False
        if nq_buy.nq_point.timestamp < snp_buy.sp_point.timestamp:
            if nq_buy.nq_point.low < snp_buy.nq_c_point.low and nq_buy.sp_c_point.low > snp_buy.sp_point.low:
                nq_buy.smt_valid = True
                snp_buy.smt_valid = True
            else:
                nq_buy.smt_valid = False
                snp_buy.smt_valid = False

        if snp_buy.smt_valid:
            # set previous fractal point
            prv_fractal = self.env['data.feed'].search(
                [('pair', '=', sp), ('fractal_high', '=', True), ('timestamp', '<', snp_buy.sp_point.timestamp)],
                order='timestamp desc', limit=1)
            if prv_fractal:
                snp_buy.previous_fractal_point = prv_fractal.id
        if nq_buy.smt_valid:
            # set previous fractal point
            prv_fractal = self.env['data.feed'].search(
                [('pair', '=', nq), ('fractal_high', '=', True), ('timestamp', '<', nq_buy.nq_point.timestamp)],
                order='timestamp desc', limit=1)
            if prv_fractal:
                nq_buy.previous_fractal_point = prv_fractal.id

    def bos_breaker(self):
        #completed sell side
        smt = self.env['data.smt'].search([('bos_done','=',False),('smt_valid','=',True)])
        for rec in smt :
            if rec.previous_fractal_point :
                if rec.smt_direction == 'buy' :
                    last_candle = self.env['data.feed'].search([('smt_check','=',True),('pair','=',rec.pair)],order='timestamp desc', limit=1)
                    if last_candle:
                        if last_candle.high > rec.previous_fractal_point.high :
                            rec.bos_done = True

                if rec.smt_direction == "sell" :
                    last_candle = self.env['data.feed'].search([('smt_check','=',True),('pair', '=', rec.pair)], order='timestamp desc',limit=1)
                    if last_candle:
                        if last_candle.low < rec.previous_fractal_point.low:
                            rec.bos_done = True


        bos = self.env['data.smt'].search([('bos_done','=',True),('fib_break','=',False)])
        for rec in bos :
            if rec.smt_direction == "buy" :
                if rec.nq_point :
                    rec.fib_big = rec.nq_point.low
                    highest = self.env['data.feed'].search([('smt_check', '=', True),('timestamp', '>', rec.nq_point.timestamp),('pair', '=', rec.nq_point.pair)], order='high desc',limit=1)
                    if highest :
                        if highest.high > rec.fib_end :
                            rec.fib_end = highest.high

                if rec.sp_point :
                    rec.fib_big = rec.sp_point.low
                    highest = self.env['data.feed'].search(
                        [('timestamp', '>', rec.sp_point.timestamp),('smt_check', '=', True), ('pair', '=', rec.sp_point.pair)],
                        order='high desc', limit=1)
                    if highest:
                        if highest.high > rec.fib_end:
                            rec.fib_end = highest.high


            if rec.smt_direction == "sell" :
                if rec.nq_point:
                    rec.fib_big = rec.nq_point.high
                    lowest = self.env['data.feed'].search(
                        [('smt_check', '=', True), ('timestamp', '>', rec.nq_point.timestamp),
                         ('pair', '=', rec.nq_point.pair)], order='low asc', limit=1)
                    if lowest:
                        if lowest.low < rec.fib_end:
                            rec.fib_end = lowest.low

                if rec.sp_point:
                    rec.fib_big = rec.sp_point.high
                    lowest = self.env['data.feed'].search(
                        [('smt_check', '=', True), ('timestamp', '>', rec.sp_point.timestamp),
                         ('pair', '=', rec.sp_point.pair)], order='low asc', limit=1)
                    if lowest:
                        if lowest.low < rec.fib_end:
                            rec.fib_end = lowest.low




