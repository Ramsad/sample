from odoo import api, fields, models
# import MetaTrader5 as mt5
from datetime import datetime
import pytz

class TnpAlgo(models.Model):
    _name = 'data.feed'
    _rec_name = 'timestamp'
    _description = 'Data Feed'

    timestamp = fields.Integer(string="Time Stamp", required=False, )
    pair = fields.Char(string="", required=False, )
    open = fields.Float(string="",  required=False, )
    high = fields.Float(string="",  required=False, )
    low = fields.Float(string="",  required=False, )
    close = fields.Float(string="",  required=False, )

    userdatetime = fields.Datetime(compute='datetime_converter')

    fractal_high = fields.Boolean(string="",  )
    fractal_low = fields.Boolean(string="",  )
    fractal_check = fields.Boolean()

    smt_check  = fields.Boolean(string="",  )

    def tsc(timestamp):
        server_time = fields.datetime.fromtimestamp(int(timestamp))
        return server_time


    @api.depends('timestamp')
    def datetime_converter(self):
        for record in self:
            if record.timestamp :
                record.userdatetime = fields.datetime.fromtimestamp(int(record.timestamp))

    def fractal_finder(self):
        records = self.env['data.feed'].search([('fractal_check',"=",False)])
        for record in records:
            p1_candle = record.env['data.feed'].search([('timestamp',"=",record.timestamp - 300),('pair','=',record.pair)])
            p2_candle = record.env['data.feed'].search([('timestamp',"=",record.timestamp - 600),('pair','=',record.pair)])
            a1_candle = record.env['data.feed'].search([('timestamp',"=",record.timestamp + 300),('pair','=',record.pair)])
            a2_candle = record.env['data.feed'].search([('timestamp',"=",record.timestamp + 600),('pair','=',record.pair)])
            if p1_candle and p2_candle and a1_candle and a2_candle :
                if record.high > p2_candle.high and \
                        record.high > p1_candle.high and \
                        record.high > a1_candle.high and \
                        record.high > a2_candle.high:
                    record.fractal_high = True


                if record.low < p2_candle.low and \
                            record.low < p1_candle.low and \
                            record.low < a1_candle.low and \
                            record.low < a2_candle.low:
                    record.fractal_low = True
                record.fractal_check = True


    def data_collector(self):
        sp = self.env.ref('tnp_algo.sp').name
        nq = self.env.ref('tnp_algo.nq').name
        gu = self.env.ref('tnp_algo.gu').name
        eu=self.env.ref('tnp_algo.eu').name

        # connect to MT5 terminal
        if not mt5.initialize():
            print("initialize() failed")
            mt5.shutdown()

        # set time zone to UTC
        # create 'datetime' object in UTC time zone to avoid the implementation of a local time zone offset
        timezone = pytz.timezone("Etc/UTC")
        # create 'datetime' objects in UTC time zone to avoid the implementation of a local time zone offset
        utc_from = datetime(2023, 5, 17,hour=0,minute=0, tzinfo=timezone)
        utc_to = datetime(2023, 5, 17, hour=23, tzinfo=timezone)
        # get bars from USDJPY M5 within the interval of 2020.01.10 00:00 - 2020.01.11 13:00 in UTC time zone
        rates_spx = mt5.copy_rates_range(sp, mt5.TIMEFRAME_M5, utc_from, utc_to)
        rates_nq = mt5.copy_rates_range(nq, mt5.TIMEFRAME_M5, utc_from, utc_to)


        for ratex in  rates_spx:
            if ratex[0]:
                check_data = self.env['data.feed'].search([('pair','=',sp),('timestamp','=',ratex[0])])
                if  not check_data :
                    sp_new_data = self.env['data.feed'].create({ 'timestamp' : ratex[0],
                                                                 'open':ratex[1],
                                                                 'high':ratex[2],
                                                                 'low':ratex[3],
                                                                 'close':ratex[4],
                                                                 'pair':sp
                                                })
                    if sp_new_data :
                        break

        for ratex in  rates_nq:
            if ratex[0]:
                check_data = self.env['data.feed'].search([('pair',"=",nq),('timestamp','=',ratex[0])])
                if  not check_data :
                    sp_new_data = self.env['data.feed'].create({ 'timestamp' : ratex[0],
                                                                 'open':ratex[1],
                                                                 'high':ratex[2],
                                                                 'low':ratex[3],
                                                                 'close':ratex[4],
                                                                 'pair':nq
                                                                 })
                    if sp_new_data :
                        break


        mt5.shutdown()


